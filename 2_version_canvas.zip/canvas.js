// PASO 1 -- CREAMOS EL CANVAS --////

let canvas;
let ctx;
let FPS = 60;
let tileMap;
let tile;
let vida = 100;
var soundComerCarne = new Audio('sound/comer_carne.wav');
let tipo7 = {};
let elementosAjenos = [tipo7];
tipo7.x = 410;
tipo7.y = 320;
tipo7.existe = true;  
let imgTipo7 = new Image();
imgTipo7.src = 'img/M_Idle.png';

var escenario = [
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5],
    [2,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,6],
    [2,9,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,13,6],
    [2,10,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,14,6],
    [2,10,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,14,6],
    [2,10,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,14,6],
    [2,10,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,14,6],
    [2,10,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,14,6],
    [2,10,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,14,6],
    [2,10,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,14,6],
    [2,10,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,14,6],
    [2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6],
    [8,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,7]
]

// PASO 2 - MEDIANTE UN SWITCH / CASE COLOCAMOS LAS IMÁGENES ////////
// PARA PROBAR QUE PASO 1 Y PASO 2 FUNCIONAN TENEMOS QUE CREAR LA FUNCION INICIAL AL FINAL
// DEL CODIGO, SI NO, NO FURULA.

function dibujarEscenario() {
    for (y = 0; y < 13; y++) {
        for (x = 0; x < 21; x++) {
            var tile = escenario[y][x]; 

            switch (tile) {
                case 0:  
                    ctx.drawImage(tileMap[0], x * 64, y * 64);
                    break;
                case 1:  
                    ctx.drawImage(tileMap[1], x * 64, y * 64);
                    break;
                case 2:  
                    ctx.drawImage(tileMap[2], x * 64, y * 64);
                    break;
                case 3:  
                    ctx.drawImage(tileMap[3], x * 64, y * 64);
                    break;
                case 4:  
                    ctx.drawImage(tileMap[4], x * 64, y * 64);
                    break;
                case 5:  
                    ctx.drawImage(tileMap[5], x * 64, y * 64);
                    break;
                case 6:  
                    ctx.drawImage(tileMap[6], x * 64, y * 64);
                    break;
                case 7:  
                    ctx.drawImage(tileMap[7], x * 64, y * 64);
                    break;
                case 8:  
                    ctx.drawImage(tileMap[8], x * 64, y * 64);
                    break;
                case 9:  
                    ctx.drawImage(tileMap[9], x * 64, y * 64);
                    break;
                case 10:  
                    ctx.drawImage(tileMap[10], x * 64, y * 64);
                    break;
                case 11:  
                    ctx.drawImage(tileMap[11], x * 64, y * 64);
                    break;
                case 12:  
                    ctx.drawImage(tileMap[12], x * 64, y * 64);
                    break;
                case 13:  
                    ctx.drawImage(tileMap[13], x * 64, y * 64);
                    break;
                case 14:  
                    ctx.drawImage(tileMap[14], x * 64, y * 64);
                    break;
            }
        }
    }
}

// PASO 3 - CREAMOS A NUESTRO WARRIOR /////////////////////////////////////////////////////////////////////

// creamos el objeto personaje y el cargarlo como OBJETO nos permite crear nuevos personajes ///////

let personaje = {
    x: 50,
    y: 200,
    velocidad: 10, // frames por segundo?
    imagen: new Image(),
    width: 192, // Ancho de cada frame de la animación
    height: 192, // Alto de cada frame de la animación
    frameIndex: 0, // Índice del frame actual, donde tiene inicio en la imagen
    tickCount: 0, // Contador para controlar la velocidad de la animación
    ticksPerFrame: 10, // Cuántos ticks pasan antes de pasar al siguiente frame
    numFrames: 6 // Total de frames en tu animación (imagen)
};

// PASO - 4 CARGAMOS A NUESTRO PERSONAJE / ES IMPRESCINDIBLE QUE LA RUTA ESTA CORRECTA SI NO NO FURULA! ////
// Y NOS VAMOS A LA FUNCIÓN INICIALIZAR ANTES DE PASAR AL PASO 5 ! IMPORTANTE ! ////
function cargarPersonaje() {
    personaje.imagen.src = 'img/Warrior_Red.png';
}

function moverPersonaje(evento) {
    switch(evento.keyCode) {
        case 37: // Tecla de flecha izquierda
            personaje.x -= personaje.velocidad;
            break;
        case 38: // Tecla de flecha arriba
            personaje.y -= personaje.velocidad;
            break;
        case 39: // Tecla de flecha derecha
            personaje.x += personaje.velocidad;
            break;
        case 40: // Tecla de flecha abajo
            personaje.y += personaje.velocidad;
            break;
    }
    // ¡COLISIONES CON EL FINAL DE CANVAS! //////////////

    if(personaje.x <= 0){
        personaje.x = 0;}

    if(personaje.x >= 1100){
        personaje.x = 1100;}

    if(personaje.y >= 565){
        personaje.y = 565;}
    
    if(personaje.y <= 20){
        personaje.y = 20;}
    
        // COLISIONES CON OBJETOS ///////////////////////////
    
        if (Math.abs(personaje.x - tipo7.x) < 15 && Math.abs(personaje.y - tipo7.y) < 15 && tipo7.existe === true) {
            console.log('he cazado la carne!');
            vida += 50;
            console.log(vida);
            soundComerCarne.play();
            elementosAjenos = elementosAjenos.filter(elemento => elemento !== tipo7);
            tipo7.existe = false;
        }
}



// CARGAMOS Y DIBUJAMOS EL ARBOL ////////////////////////////////
// Array para almacenar múltiples árboles
var arboles = [
    {
        x: 540,
        y: -5,
        imagen: new Image(),
        width: 192,
        height: 192,
        frameIndex: 0,
        tickCount: 0,
        ticksPerFrame: 4,
        numFrames: 4,
    },
    // Agrega otro árbol con coordenadas específicas
    {
        x: 300, // Coordenada X del nuevo árbol
        y: 100, // Coordenada Y del nuevo árbol
        imagen: new Image(),
        width: 192,
        height: 192,
        frameIndex: 0,
        tickCount: 0,
        ticksPerFrame: 4,
        numFrames: 4,
    },

    {
        x: 643, // Coordenada X del nuevo árbol
        y: 456, // Coordenada Y del nuevo árbol
        imagen: new Image(),
        width: 192,
        height: 192,
        frameIndex: 0,
        tickCount: 0,
        ticksPerFrame: 4,
        numFrames: 4,
    },

    {
        x: 1000, // Coordenada X del nuevo árbol
        y: 525, // Coordenada Y del nuevo árbol
        imagen: new Image(),
        width: 192,
        height: 192,
        frameIndex: 0,
        tickCount: 0,
        ticksPerFrame: 4,
        numFrames: 4,
    }
    // Puedes seguir agregando más árboles aquí
];

function cargarArboles() {
    const promesas = arboles.map(arbol => {
        return new Promise(resolve => {
            arbol.imagen.onload = resolve;
            arbol.imagen.src = 'img/Tree.png'; // Asegúrate de que esta sea la ruta correcta
        });
    });
    return Promise.all(promesas); // Espera a que todas las imágenes se carguen
}

function dibujarArboles() {
    arboles.forEach(arbol => {
        ctx.drawImage(
            arbol.imagen,
            arbol.frameIndex * arbol.width, 0,
            arbol.width, arbol.height,
            arbol.x, arbol.y,
            arbol.width, arbol.height
        );
        // Actualiza el frame del árbol para la próxima vez
        actualizarFrameArbol(arbol);
    });
}

function actualizarFrameArbol(arbol) {
    arbol.tickCount += 1;
    if (arbol.tickCount > arbol.ticksPerFrame) {
        arbol.tickCount = 0;
        arbol.frameIndex = (arbol.frameIndex + 1) % arbol.numFrames;
    }
}


////// CARGAMOS ARBUSTOS ///////

// Estructura para almacenar las imágenes de los arbustos
var imagenesArbustos = {};

var tiposDeArbustos = {
    'tipo1': {
        src: 'img/09.png',
        posiciones: [
            { x: 340, y: 90, width: 64, height: 64 },
            { x: 370, y: 87, width: 64, height: 64 },
            { x: 200, y: 84, width: 64, height: 64 },
            { x: 400, y: 92, width: 64, height: 64 },
            { x: 700, y: 84, width: 64, height: 64 },
            { x: 730, y: 90, width: 64, height: 64 },
            { x: 790, y: 103, width: 64, height: 64 },
            { x: 843, y: 83, width: 64, height: 64 },
            { x: 873, y: 85, width: 64, height: 64 },
            { x: 943, y: 93, width: 64, height: 64 },
            { x: 1100, y: 84, width: 64, height: 64 },
            { x: 900, y: 357, width: 64, height: 64 },
            { x: 850, y: 347, width: 64, height: 64 },
            { x: 875, y: 380, width: 64, height: 64 },
            // Más posiciones para el tipo1...
        ]
    },
    'tipo2': {
        src: 'img/11.png',
        posiciones: [
            { x: 450, y: 93, width: 64, height: 64 },
            { x: 400, y: 89, width: 64, height: 64 },
            { x: 230, y: 84, width: 64, height: 64 },
            { x: 703, y: 84, width: 64, height: 64 },
            { x: 793, y: 95, width: 64, height: 64 },
            { x: 856, y: 90, width: 64, height: 64 },
            { x: 960, y: 84, width: 64, height: 64 },
            { x: 1150, y: 84, width: 64, height: 64 },
            { x: 1115, y: 105, width: 64, height: 64 },
            { x: 870, y: 370, width: 64, height: 64 },
            // Más posiciones para el tipo2...
        ]
    },
    'tipo3': {
        src: 'img/03.png',
        posiciones: [
            { x: 600, y: 200, width: 64, height: 64 },
            { x: 850, y: 390, width: 64, height: 64 },
            // Más posiciones para el tipo2...
        ]
    },
    'tipo4': {
        src: 'img/02.png',
        posiciones: [
            { x: 615, y: 210, width: 64, height: 64 },
            { x: 565, y: 200, width: 64, height: 64 },
            // Más posiciones para el tipo2...
        ]
    },
    'tipo5': {
        src: 'img/01.png',
        posiciones: [
            { x: 625, y: 185, width: 64, height: 64 },
            { x: 576, y: 215, width: 64, height: 64 },
            // Más posiciones para el tipo2...
        ]
    },
    'tipo6': { // TORRE ROJA
        src: 'img/Tower_Red.png',
        posiciones: [
            { x: 75, y: -10, width: 128, height: 256 },
            
            // Más posiciones para el tipo2...
        ]
    }
    
    // AGREGAMOS CONSTRUCCIONES A ESTA FUNCIÓN
};

function cargarImagenesArbustos() {
    let promesas = [];
    for (let tipo in tiposDeArbustos) {
        let img = new Image();
        promesas.push(new Promise(resolve => {
            img.onload = () => {
                imagenesArbustos[tipo] = img;
                resolve();
            };
            img.src = tiposDeArbustos[tipo].src;
        }));
    }
    return Promise.all(promesas);
}

function dibujarArbustos() {
    for (let tipo in tiposDeArbustos) {
        tiposDeArbustos[tipo].posiciones.forEach(pos => {
            ctx.drawImage(
                imagenesArbustos[tipo],
                pos.x, pos.y,
                pos.width, pos.height
            );
        });
    }
}


// END ///  ¡COLISIONES CON EL FINAL DE CANVAS! //////////////

// Añade el escuchador de eventos para las teclas
function configurarControles() {
    window.addEventListener('keydown', moverPersonaje);
}

function actualizarEscenario() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    dibujarEscenario();
    personaje.tickCount++;

    if (personaje.tickCount > personaje.ticksPerFrame) {
        personaje.tickCount = 0;

        // Actualizar el frame del personaje
        if (personaje.frameIndex < personaje.numFrames - 1) {
            personaje.frameIndex++;
        } else {
            personaje.frameIndex = 0;
        }
    }

    // DIBUJAMOS EL PERSONAJE 
    ctx.drawImage(
        personaje.imagen,
        personaje.frameIndex * personaje.width, 0,
        personaje.width, personaje.height,
        personaje.x, personaje.y,
        personaje.width, personaje.height,
    );
    console.log(personaje.x, personaje.y);
    dibujarArbustos();
    dibujarArboles();
}

function dibujarElementos(){
    if (tipo7.existe === true) {
        ctx.drawImage(imgTipo7, tipo7.x, tipo7.y);
    }
}

function cicloPrincipal() {
    actualizarEscenario();
    requestAnimationFrame(cicloPrincipal);
    dibujarElementos();
    
    // Llamar a esta función en tu bucle de juego, pasando el objeto de tu personaje como argumento
    // verificarColisionConTipo7(miPersonaje);
    
}


// FIN PERSONAJE //////////////////////////////////////////////////////////////////////////////////




function iniciar() {
    // INICIAMOS EL CANVAS //////
    canvas = document.getElementById("canvas");
    if (!canvas) {
        console.error('no se ha cargado canvas!');
        return;
    }
    ctx = canvas.getContext('2d');

    // Define tileSources aquí dentro de la función iniciar
    const tileSources = [
        'img/tile-1.png', 'img/tile-2.png', 'img/tile-3.png', 'img/tile-4.png',
        'img/tile-5.png', 'img/tile-6.png', 'img/tile-7.png', 'img/tile-8.png',
        'img/tile-9.png', 'img/ground-1.png', 'img/ground-2.png', 'img/ground-3.png',
        'img/ground-4.png', 'img/ground-5.png', 'img/ground-6.png'
    ];
    // CANVAS INICIADO

    // Carga la imagen para los arbustos
    cargarImagenesArbustos().then(() => {
        console.log("Arbustos cargados.");

        // Carga las imágenes de los tiles
        const tilePromises = tileSources.map(src => new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => resolve(img);
            img.onerror = reject;
            img.src = src;
        }));

        Promise.all(tilePromises).then(loadedImages => {
            tileMap = loadedImages;
            console.log("Tiles cargados.");

            // Carga las imágenes de los árboles
            cargarArboles().then(() => {
                console.log("Árboles cargados.");

                // Todo está cargado, inicia el ciclo principal
                cargarPersonaje(); // Asegúrate de que esta función no necesite esperar a que la imagen se cargue
                configurarControles();
                requestAnimationFrame(cicloPrincipal);
            }).catch(error => console.error("Error al cargar los árboles:", error));
        }).catch(error => console.error("Error al cargar los tiles:", error));
    }).catch(error => console.error("Error al cargar los arbustos:", error));
}
