var canvas;
var ctx;
var FPS = 60;
var tileMap;
var tile;

var escenario = [
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5],
    [2,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,6],
    [2,9,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,13,6],
    [2,10,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,14,6],
    [2,10,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,14,6],
    [2,10,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,14,6],
    [2,10,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,14,6],
    [2,10,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,14,6],
    [2,10,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,14,6],
    [2,10,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,14,6],
    [2,10,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,14,6],
    [2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6],
    [8,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,7]
]

function dibujarEscenario() {
    for (y = 0; y < 13; y++) {
        for (x = 0; x < 21; x++) {
            var tile = escenario[y][x]; 

            switch (tile) {
                case 0:  
                    ctx.drawImage(tileMap[0], x * 64, y * 64);
                    break;
                case 1:  
                    ctx.drawImage(tileMap[1], x * 64, y * 64);
                    break;
                case 2:  
                    ctx.drawImage(tileMap[2], x * 64, y * 64);
                    break;
                case 3:  
                    ctx.drawImage(tileMap[3], x * 64, y * 64);
                    break;
                case 4:  
                    ctx.drawImage(tileMap[4], x * 64, y * 64);
                    break;
                case 5:  
                    ctx.drawImage(tileMap[5], x * 64, y * 64);
                    break;
                case 6:  
                    ctx.drawImage(tileMap[6], x * 64, y * 64);
                    break;
                case 7:  
                    ctx.drawImage(tileMap[7], x * 64, y * 64);
                    break;
                case 8:  
                    ctx.drawImage(tileMap[8], x * 64, y * 64);
                    break;
                case 9:  
                    ctx.drawImage(tileMap[9], x * 64, y * 64);
                    break;
                case 10:  
                    ctx.drawImage(tileMap[10], x * 64, y * 64);
                    break;
                case 11:  
                    ctx.drawImage(tileMap[11], x * 64, y * 64);
                    break;
                case 12:  
                    ctx.drawImage(tileMap[12], x * 64, y * 64);
                    break;
                case 13:  
                    ctx.drawImage(tileMap[13], x * 64, y * 64);
                    break;
                case 14:  
                    ctx.drawImage(tileMap[14], x * 64, y * 64);
                    break;
            }
        }
    }
}

function iniciar() {
    canvas = document.getElementById("canvas");
    ctx = canvas.getContext('2d');
    tileMap = [
        new Image(), new Image(), new Image(), new Image(), new Image(), new Image(), new Image(), new Image(), new Image() ,new Image() ,new Image() ,new Image(), new Image(), new Image(), new Image(), new Image()
    ];
    tileMap[0].src = 'img/tile-1.png';
    tileMap[1].src = 'img/tile-2.png';
    tileMap[2].src = 'img/tile-3.png';
    tileMap[3].src = 'img/tile-4.png';
    tileMap[4].src = 'img/tile-5.png';
    tileMap[5].src = 'img/tile-6.png';
    tileMap[6].src = 'img/tile-7.png';
    tileMap[7].src = 'img/tile-8.png';
    tileMap[8].src = 'img/tile-9.png';
    tileMap[9].src = 'img/ground-1.png';
    tileMap[10].src = 'img/ground-2.png';
    tileMap[11].src = 'img/ground-3.png';
    tileMap[12].src = 'img/ground-4.png';
    tileMap[13].src = 'img/ground-5.png';
    tileMap[14].src = 'img/ground-6.png';

    tileMap[0].onload = function () {
        dibujarEscenario();
    };
}